package com.example.assignment2;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

import ModelPackage.GameManager;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    private FloatingActionButton move;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        move = findViewById(R.id.floatingBtn);
        move.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                startActivity(intent);
            }
        });
        getSupportActionBar().setTitle("Games Played");
        GameManager gameManager= new GameManager();

        //if(gameManager.game.size()==0)
        listView =(ListView)findViewById(R.id.listview);
        ArrayList<String> arrayList= new ArrayList<>();
        arrayList.add("android");
        arrayList.add("is");
        arrayList.add("and I love it");
        arrayList.add("It");
        arrayList.add("is");
        arrayList.add("better");
        arrayList.add("than");
        arrayList.add("many");
        arrayList.add("other");
        arrayList.add("operating system. ");

        ArrayAdapter arrayAdapter= new ArrayAdapter(this, android.R.layout.simple_list_item_1,arrayList);
        listView.setAdapter(arrayAdapter);

    }
}

