package com.example.assignment2;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import java.time.LocalDateTime;
import java.util.Date;

import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import ModelPackage.Game;
import ModelPackage.playerScore;

//private int TextWatcher= new TextWatcher();


//@RequiresApi(api = Build.VERSION_CODES.O)
public class MainActivity2 extends AppCompatActivity {
    private Game g= new Game(2);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        getSupportActionBar().setTitle("New Game Score");

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        EditText txtPlayer1cards= findViewById(R.id.player1cards);
        //txtPlayer1cards.setOnClickListener((View.OnClickListener) this);
        EditText txtPlayer2cards= findViewById(R.id.player2cards);
        EditText sumPoints1= findViewById(R.id.sumPoints1);
        //sumPoints1.setOnClickListener((View.OnClickListener) this);

        EditText sumPoints2= findViewById(R.id.sumPoints2);

        EditText numberWager1= findViewById(R.id.numberWagers1);
        //numberWager1.setOnClickListener((View.OnClickListener) this);
        EditText numberWager2= findViewById(R.id.numberWager2);
        EditText editTextDate= findViewById(R.id.editDate);


        editTextDate.setText(g.getDate().toString());
        int num1 =0,num2 = 0,num3 =0;
        try {
            //txtPlayer1cards.setOnClickListener((View.OnClickListener) this);
            String s1= txtPlayer1cards.getText().toString();
            num1= Integer.parseInt(s1);
        }catch(NumberFormatException nfe){
            System.out.println("Could not parse"+nfe);
        }
        try {
            //sumPoints1.setOnClickListener((View.OnClickListener) this);
            String s2= sumPoints1.getText().toString();
            num2= Integer.parseInt(s2);
        }catch(NumberFormatException nfe){
            System.out.println("Could not parse"+nfe);
        }
        try {
            //numberWager1.setOnClickListener((View.OnClickListener) this);
            String s3= numberWager1.getText().toString();
            num3= Integer.parseInt(s3);
        }catch(NumberFormatException nfe){
            System.out.println("Could not parse"+nfe);
        }
        if(num1!=0 && num2!=0 && num3!=0) {
            playerScore p = new playerScore(num1, num2, num3);
            int total = p.totalScore();
            String s= String.valueOf(total);
            TextView score1 = findViewById(R.id.scores1);
            score1.setText(s);
        }


        //editTextDate.setText(date.now());

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_score,menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId()){
            case R.id.action_save:
                //to code action for save button
                break;
            default:
                return super.onOptionsItemSelected(item);
        }
        return true;
    }
//    public void onBtnClick(View v)
//    {
//        EditText txtPlayer1cards= findViewById(R.id.player1cards);
//        EditText txtPlayer2cards= findViewById(R.id.player2cards);
//        EditText sumPoints1= findViewById(R.id.sumPoints1);
//        EditText sumPoints2= findViewById(R.id.sumPoints2);
//        EditText numberWager1= findViewById(R.id.numberWagers1);
//        EditText numberWager2= findViewById(R.id.numberWager2);


//        TextView edtTextFirstName = findViewById(R.id.txtview1);
//        EditText txtLastName= findViewById(R.id.txtLastName);
//        TextView edtTextLastName = findViewById(R.id.txtview2);
//        EditText txtEmail= findViewById(R.id.txtEmail);
//        TextView edtEmail = findViewById(R.id.txtview3);
//        edtTextFirstName.setText("First Name: "+ txtFirstName.getText().toString());
//        edtTextLastName.setText("Last Name: "+ txtLastName.getText().toString());
//        edtEmail.setText("Email: "+ txtEmail.getText().toString());
 //   }

}

