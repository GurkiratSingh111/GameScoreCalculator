package ModelPackage;
import android.os.Build;


import androidx.annotation.RequiresApi;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class Game {
    private int numberOfPlayers;
    private ArrayList<playerScore> player = new ArrayList<playerScore>();
    private String date;
    public static Game instance;
    private Game(){
        //Private to prevent anyone else from instantiating
    }
    public static Game getInstance(){
        if(instance == null)
            instance = new Game();
        return instance;
    }

//    public LocalDateTime getDate()
//    {
//        return date;
//    }
    public String getDate(){
        LocalDateTime obj = LocalDateTime.now();
        DateTimeFormatter myformat = DateTimeFormatter.ofPattern("MMM d @ HH:mm a");
        String formatted_date = obj.format(myformat);
        return formatted_date;
    }

    public  int getNumberOfPlayers()
    {
        return numberOfPlayers;
    }
    public void setNumberOfPlayers(int numberOfPlayers)
    {
        this.numberOfPlayers= numberOfPlayers;
    }

//    public Game(int num)
//    {
//        numberOfPlayers=num;
//        date= getDate();
//        player= new ArrayList<playerScore>();
//    }

    //This function returns an arraylist of winners of the game
    public ArrayList<Integer> calculatewinner()
    {
        ArrayList<Integer> winner = new ArrayList<>();
        int highestScore= player.get(0).totalScore();
        for(int i=0;i<player.size();i++)
        {
            if(player.get(i).totalScore()>highestScore)
                highestScore= player.get(i).totalScore();
        }
        for(int i=0; i<player.size();i++) {
            if (player.get(i).totalScore() == highestScore)
                winner.add(i + 1);
        }
        return winner;
    }
}
